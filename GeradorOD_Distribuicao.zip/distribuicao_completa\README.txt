# Sistema Gerador de OD - Executável

## Como usar:

1. Certifique-se de que os arquivos estão na pasta 'arquivos/':
   - DECUPAGEM.csv (planilha com as cenas)
   - PLANO_FINAL.pdf (cronograma de filmagem)

2. Abra o terminal/prompt na pasta do executável

3. Execute um dos comandos:
   - Para gerar OD de um dia específico: `GeradorOD.exe 1`
   - Para gerar todas as ODs: `GeradorOD.exe all`

4. Os arquivos OD serão gerados na pasta `arquivos/ODs/`

## Estrutura de pastas necessária:
```
pasta_do_executavel/
├── GeradorOD.exe
├── arquivos/
│   ├── DECUPAGEM.csv
│   ├── PLANO_FINAL.pdf
│   └── ODs/
│       ├── OD_Dia_1.xlsx
│       ├── OD_Dia_2.xlsx
│       └── ...
└── README.txt (este arquivo)
```

## Exemplos de uso:
- `GeradorOD.exe 1` - Gera apenas a OD do dia 1
- `GeradorOD.exe 3` - Gera apenas a OD do dia 3  
- `GeradorOD.exe all` - Gera todas as ODs de uma vez

## Suporte:
Para problemas ou dúvidas, entre em contato com o desenvolvedor.
